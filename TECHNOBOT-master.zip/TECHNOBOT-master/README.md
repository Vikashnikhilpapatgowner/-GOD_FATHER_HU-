
<h1 align="center">⚡ 𝕋𝕖𝕔𝕙𝕟𝕠𝔹𝕠𝕥 ⚡</h1>

[![Bot logo](https://telegra.ph/file/b3af720021620b4f88a66.jpg)](https://t.me/TechnoBot_Support)


<h6>This is a userbot made for telegram. 
This is the one and only official TechnoBot💖 Userbot made by @Technoboy_02. Don't forget to star this repo if you liked it. Enjoy Your Bot!!💝</h6>

[![](https://img.shields.io/badge/TECHNOBOT-v1.1-blue)](#)
[![Stars](https://img.shields.io/github/stars/TECHNOBOT-OP/TECHNOBOT?style=flat-square&color=yellow)](https://github.com/TECHNOBOT-OP/TECHNOBOT/stargazers)
[![Forks](https://img.shields.io/github/forks/TECHNOBOT-OP/TECHNOBOT?style=flat-square&color=orange)](https://github.com/TECHNOBOT-OP/TECHNOBOT/fork)
[![Size](https://img.shields.io/github/repo-size/TECHNOBOT-OP/TECHNOBOT?style=flat-square&color=green)](https://github.com/TECHNOBOT-OP/TECHNOBOT/)   
[![Python](https://img.shields.io/badge/Python-v3.10.13-blue)](https://www.python.org/)
[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://github.com/TECHNOBOT-OP/TECHNOBOT/graphs/commit-activity)   
[![Open Source Love svg2](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)](https://github.com/TECHNOBOT-OP/TECHNOBOT)
[![Contributors](https://img.shields.io/github/contributors/TECHNOBOT-OP/TECHNOBOT?style=flat-square&color=green)](https://github.com/TECHNOBOT-OP/TECHNOBOT/graphs/contributors)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](https://makeapullrequest.com)
[![License](https://img.shields.io/badge/License-AGPL-blue)](https://github.com/TECHNOBOT-OP/TECHNOBOT/blob/master/LICENSE)   

------

## Status Of Bot 
<p align="left">
    <a href="https://github.com/TECHNOBOT-OP/TECHNOBOT/network/members"><img src="https://img.shields.io/github/forks/TECHNOBOT-OP/TECHNOBOT?label=Forks&logoColor=Black&style=social"></a><p align="left"><a href="https://github.com/TECHNOBOT-OP/TECHNOBOT/stargazers"><img src="https://img.shields.io/github/stars/TECHNOBOT-OP/TECHNOBOT?logoColor=Blue&style=social"></a><p align="left"><a href="https://github.com/TECHNOBOT-OP/TECHNOBOT"></a><p align="left"><a href="https://github.com/TECHNOBOT-OP/TECHNOBOT?"></a>

------

## Telegram 🏪
- [![Telegram Group](https://img.shields.io/badge/Telegram-Group-brightgreen)](https://t.me/TechnoBot_Support)
- [![Telegram Channel](https://img.shields.io/badge/Telegram-Channel-brightgreen)](https://t.me/TechnoBot_Updates)

<h2 align="center">The owner would not be responsible for any kind of bans due to the bot.</h2>

<h1 align="center">FORK AT YOUR OWN RISK</h1>

<h2 align="center">⚙️ D E P L O Y I N G ⚙️</h2>


<h3> ∂єρℓσу тσ нєяσкυ</h3>

<p align="center"><a href="https://heroku.com/deploy"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-grey?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
</a>

<h3> ᴅᴇᴘʟᴏʏ ᴛᴏ ᴋᴏʏᴇʙ </h3>

<p align="center"><a href="https://app.koyeb.com/deploy?type=git&repository=github.com/TECHNOBOT-OP/TECHNOUSERBOT&branch=master&ports=8080;http;/&name=tbot&run_command=gunicorn+app:app+%26+python3+-m+Technobot&env[PORT]=8080&env[ENV]=True&env[ALIVE_NAME]=None&env[APP_ID]=None&env[API_HASH]=None&env[TECHNO_STRING]=None&env[BOT_TOKEN]=None&env[DATABASE_URL]=None&env[EXTRA_REPO]=True&env[UPSTREAM_REPO]=pro&env[TZ]=Asia/Kolkata](https://app.koyeb.com/apps/deploy?type=git&repository=github.com%2FTECHNOBOT-OP%2FTECHNOUSERBOT&branch=master&ports=8080%3Bhttp%3B%2F&name=tbot&run_command=gunicorn+app%3Aapp+%26+python3+-m+Technobot&env%5BPORT%5D=8080&env%5BENV%5D=True&env%5BALIVE_NAME%5D=None&env%5BAPP_ID%5D=None&env%5BAPI_HASH%5D=None&env%5BTECHNO_STRING%5D=None&env%5BBOT_TOKEN%5D=None&env%5BDATABASE_URL%5D=None&env%5BEXTRA_REPO%5D=True&env%5BUPSTREAM_REPO%5D=pro&env%5BTZ%5D=Asia%2FKolkata"> <img src="https://www.koyeb.com/static/images/deploy/button.svg">


<h3> StringSession </h3>

[![GenerateString](https://img.shields.io/badge/repl.it-generateString-yellowgreen)](https://replit.com/@Technoboy02/TechnoString?v=1) 

    - Click On Generate String
    - Then Click On Green Run Button.
    - Wait for a while then fill the details.
    - String will be saved in your Saved Message.


<h1 align="center">TO HOST 𝕋𝕖𝕔𝕙𝕟𝕠𝔹𝕠𝕥 LOCALLY ON ANY OTHER VPS FOLLOW THE CMDS</h1>

```bash
sudo apt update && sudo apt upgrade -y

sudo apt install --no-install-recommends -y curl git libffi-dev libjpeg-dev libwebp-dev python3-lxml python3-psycopg2 libpq-dev libcurl4-openssl-dev libxml2-dev libxslt1-dev python3-pip python3-sqlalchemy openssl wget python3 python3-dev libreadline-dev libyaml-dev gcc zlib1g ffmpeg libssl-dev libgconf-2-4 libxi6 unzip libopus0 libopus-dev python3-venv libmagickwand-dev pv tree mediainfo

git clone https://github.com/TECHNOBOT-OP/TECHNOUSERBOT tbot

cd tbot

sudo apt install virtualenv

sudo apt install nano

mv exampleconfig.py config.py
```

```bash
nano config.py
```
 (fill this) -> ctrl+x -> y -> enter

```bash
sudo apt install screen

screen -S tbot

virtualenv venv

source venv/bin/activate

pip3 install -r requirements.txt

sudo apt install tmux

tmux

source venv/bin/activate

pip3 install -r requirements.txt

python3 -m Technobot
```
 
 
------

## Variables

- `APP_ID`  =  Get this value from my.telegram.org
- `API_HASH`  =  Get this value from my.telegram.org
- `TECHNO_STRING`  =  Get this by using [Repl.it](#Repl) or from [terminal](#Terminal)
- `BOT_TOKEN`  =  Make A Bot From [@BotFather](https://t.me/botfather) and paste it's token.
- `DB_URI` = Use Sql Database  From elephantsql.com
- `HANDLER` = Use Your Command Handler Any Symbol
- `EXTRA_REPO` = True / False
- `UPSTREAM_REPO` = pro
- `TZ` = Asia/Kolkata 

    </details>
------

- The userbot will not work without setting these vars.


### Official Supports ✅ 


```
Get help regarding setting up 

your 𝕋𝕖𝕔𝕙𝕟𝕠𝔹𝕠𝕥 in our official 

support Group and get updates

notifications in Update Channel.
```

<a href="https://t.me/TechnoBot_Updates"><img src="https://img.shields.io/badge/Join-Support%20Channel-red.svg?style=for-the-badge&logo=Telegram"></a>

<a href="https://t.me/TechnoBot_Support"><img src="https://img.shields.io/badge/Join-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>


[![Contact Me](https://img.shields.io/badge/Telegram-Contact%20Me-informational)](https://t.me/Technoboy_02)


<details>

  <summary> • LICENSE • </summary>

![](https://www.gnu.org/graphics/gplv3-or-later.png)

Copyright (C) 2022 𝕋𝕖𝕔𝕙𝕟𝕠𝔹𝕠𝕥

Poject [𝕋𝕖𝕔𝕙𝕟𝕠𝔹𝕠𝕥](https://github.com/TECHNOBOY-OP/TECHNOBOT) is free software: you can redistribute it and/or modify

it under the terms of the GNU General Public License as published by

the Free Software Foundation, either version 3 of the License, or

(at your option) any later version.

This program is distributed in the hope that it will be useful,

but WITHOUT ANY WARRANTY; without even the implied warranty of

MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

GNU General Public License for more details.

You should have received a copy of the GNU General Public License

along with this program. If not, see <https://www.gnu.org/licenses/>.

</details>

<details>

  <summary> • Credits 🏅 • </summary>
  
• Inspired from all the userbots available publically for telegram.

• Motivated mainly by LEGENDBOT and Catuserbot.

• [LonamiWebs](https://github.com/LonamiWebs/Telethon) for Telethon.

• [TECHNO](https://github.com/TECHNOBOT-OP):DEV

• Plugins credit goes to [LEGENDBOT](https://github.com/LEGEND-AI/LEGENDBOT)
